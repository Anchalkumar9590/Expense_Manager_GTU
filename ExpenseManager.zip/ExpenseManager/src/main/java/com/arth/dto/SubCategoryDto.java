package com.arth.dto;

public interface SubCategoryDto {


 
	public Integer getSubCategoryId();
	public String getSubCategoryName();
	public String getCategoryName(); 
	public Integer getCategoryId();
	public String getSubcategoryName();
	
 

}
